import MetodyKalk.*;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
public class Kalkulator
{
	KalkulatorMetody met2=new KalkulatorMetody();
	ProcentyLiczby met3=new ProcentyLiczby();
	ProcentyMetody met4=new ProcentyMetody();
	public static void main (String[]args) throws FileNotFoundException 
	{
		Kalkulator met1 = new Kalkulator();
		met1.Menu();			
	}
	public void Menu()
	{
		
		Scanner key=new Scanner(System.in);
		char wybor;
		System.out.print(" -------------------------------------------------------------------\n");
		System.out.print("| Wci�nij odpowiedni znak i zatwierd� enterem aby wybra� dzia�anie: |\n");
		System.out.print(" -------------------------------------------------------------------\n");
		System.out.println("  ' 1 ' - Dodawanie");
		System.out.println("  ' 2 ' - Odejmowanie");
		System.out.println("  ' p ' - Obliczanie procent�w");
		System.out.println("  ' e ' - Zako�cz\n");
		try
		{
			switch(wybor=key.next().charAt(0))
			{
				
				case '1':
					met2.Suma();
					met4.Sleep(1000);
					Menu();
				case '2':
					met2.Roznica();
					met4.Sleep(1000);
					Menu();
				case 'p':
					met4.Sleep(1000);				
					met3.Start(2.0);
				case 'e':
					System.exit(1);
				default:
					System.out.println("Z�y wyb�r! Zacznij jeszcze raz");
					met4.Sleep(2000);
					Menu();
			}
		}
		catch(InputMismatchException e)
		{
			System.out.println("Z�y wyb�r! Zacznij jeszcze raz");
			met4.Sleep(2000);
			Menu();
		}
	}
} 