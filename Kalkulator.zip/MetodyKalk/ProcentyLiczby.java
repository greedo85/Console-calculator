package MetodyKalk;
import java.util.*;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
public class ProcentyLiczby 
{
	ProcentyMetody met=new ProcentyMetody();
	char choose;
	Scanner key=new Scanner(System.in);
	
	public double Start(double liczba)
	{	
		Kalkulator kal=new Kalkulator();
		System.out.print(" -------------------------------------------------------------------\n");
		System.out.print("| Wci�nij odpowiedni znak i zatwierd� enterem aby wybra� dzia�anie: |\n");
		System.out.print(" -------------------------------------------------------------------\n");
		System.out.println("  ' % ' - Oblicz % z liczby\n  ' z ' - Oblicz procent liczby z liczby\n  ' o ' - Oblicz o jaki procent zmala�a liczba\n  ' + ' - Dodaj procent do liczby\n  ' - ' - Odejmij procent do liczby\n  ' k ' - Kalkulator\n  ' e ' - Zako�cz");
		choose=key.next().charAt(0);
		try
		{
			switch (choose)
			{
				case '%':
					try
					{
						System.out.println("Wpisz procent i liczb� z kt�rej chcesz go policzy�:");
						met.procentLiczby(key.nextDouble(), key.nextDouble());
						met.Sleep(2000);
						Start(2.0);
					}
					catch (InputMismatchException e)
					{
						System.out.println("To nie liczba");
						met.Sleep(1000);
						Start(2.0);
					}	
				case 'z':
					try
					{
						System.out.println("Wpisz pierwsz� liczb� kt�rej procentem b�dzie druga liczba:");
						met.LiczbaZLiczby(key.nextDouble(), key.nextDouble());
						met.Sleep(2000);
						Start(2.0);
					}
					catch (InputMismatchException e)
					{
						System.out.println("To nie liczba");
						met.Sleep(2000);
						Start(2.0);
					}	
				case 'o':
					try
					{
						System.out.println("O jaki procent zmala�a lub zwi�kszy�a si� jedna liczba wzgl�dem drugiej: ");
						System.out.println("(Wpisz pierwsz� liczb� zatwierd� enterem i drug� r�wnie� zatwierd� enterem)");
						met.oJakiProcent(key.nextDouble(), key.nextDouble());
						met.Sleep(2000);
						Start(2.0);
					}
					catch (InputMismatchException e)
					{
						System.out.println("To nie liczba");
						met.Sleep(1000);
						Start(2.0);
					}
				case '+':
					try
					{
						System.out.println("Wpisz liczb� i procent jaki chcesz do niej doda�: ");
						met.dodajProcent(key.nextDouble(), key.nextDouble());
						met.Sleep(2000);
						Start(2.0);
					}
					catch (InputMismatchException e)
					{
						System.out.println("To nie liczba");
						met.Sleep(1000);
						Start(2.0);
					}
				case '-':
					try
					{
						System.out.println("Wpisz liczb� i procent jaki chcesz od niej odj��: ");
						met.odejmijProcent(key.nextDouble(), key.nextDouble());
						met.Sleep(2000);
						Start(2.0);
					}
					catch (InputMismatchException e)
					{
						System.out.println("To nie liczba");
						met.Sleep(1000);
						Start(2.0);
					}
				case 'k':
					try
					{
						met.Sleep(2000);
						kal.Menu();
					}
					catch (InputMismatchException e)
					{
						System.out.println("To nie liczba");
						met.Sleep(2000);
						Start(2.0);
					}
				case 'e':
				{
					System.exit(1);
				}
				default:
					System.out.println("Z�y wyb�r! Zacznij jeszcze raz"); 
					met.Sleep(2000);
					Start(2.0);
			}
		}
		catch(InputMismatchException e)
		{
			System.out.println("Z�y wyb�r! Zacznij jeszcze raz");
			met.Sleep(2000);
			Start(2.0);
		}
		return liczba;
	}	
}
