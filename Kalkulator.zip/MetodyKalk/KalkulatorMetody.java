package MetodyKalk;
import java.util.Scanner;
public class KalkulatorMetody
{
	ProcentyMetody met4=new ProcentyMetody();
	Scanner key=new Scanner(System.in);
	double liczba;
	double wynik=0;
	char wybor;
	public void Suma()
	{
		System.out.println("Wpisz liczby kt�re chcesz zsumowa�, naciskaj�c Enter po ka�dej.\nAby pozna� wynik, wpisz '0' i zatwierd� enterem");
		for (int i=0; i<200; i++)
		{				
			liczba=key.nextDouble();
			wynik=wynik+liczba;
			if (liczba==0)
			{
				System.out.println("Suma liczb to: "+wynik);
				met4.Sleep(2000);
				wynik=0;
				break;
			}
		}
	}
	public void Roznica()
	{
		System.out.println("Wpisz liczby kt�re chcesz odj��, naciskaj�c Enter po ka�dej.\nAby pozna� wynik, wpisz '0' i zatwierd� enterem");
		for (int i=0; i<200; i++)
		{
			liczba=key.nextDouble();
			wynik=wynik-liczba;
			if(i==0)
			{
				wynik=liczba;
			}
			if (liczba==0)
			{
				System.out.println("R�nica liczb to: "+wynik);
				met4.Sleep(2000);
				wynik=0;
				break;
			}
		}
	}
	void Mnozenie()
	{
	}
		
}
 