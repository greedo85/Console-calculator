package MetodyKalk;
import java.util.*;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
public class ProcentyMetody 
{
	double liczba1;
	double liczba2;
	public double wynik;
	
	public double procentLiczby(double liczba1, double liczba2)
	{
		wynik=liczba1/100*liczba2;
		System.out.println(liczba1+"% z "+liczba2+" wynosi "+wynik);
		return wynik;
	}
	public double dodajProcent (double liczba1, double liczba2)
	{
		wynik=liczba1+(liczba1*liczba2/100);
		System.out.println(liczba1+" zwi�kszona o "+(int)liczba2+" procent wynosi: "+wynik);
		return wynik;
	}
	public double odejmijProcent (double liczba1, double liczba2)
	{
		wynik=liczba1-(liczba1*liczba2/100);
		System.out.println(liczba1+" zmniejszona o "+(int)liczba2+" procent wynosi: "+wynik);
		return wynik;
	}
	public double LiczbaZLiczby(double liczba1, double liczba2)
	{
		wynik=liczba1/liczba2*100;
		System.out.println(liczba1+" jest "+wynik+"% z "+liczba2);
		return wynik;
	}
	public double oJakiProcent(double liczba1, double liczba2)
	{
		double wynik1=(liczba1-liczba2);
		wynik=wynik1/liczba2*100;
		if(liczba1>liczba2)
		{
			System.out.println(liczba1+" zwi�kszy�a si� wzgl�dem "+liczba2+ " o "+wynik);
		}
		else if(liczba2>liczba1)
		{
			System.out.format(liczba1+" zmniejszy�a si� wzgl�dem "+liczba2+ " o "+wynik);
		}
		else if(liczba1==liczba2)
		{
			System.out.println(liczba1+" nie zmniejszy�a si� wzgl�dem "+liczba2+ " o "+wynik);
		}
		return wynik;
	}
	public void Sleep(int time)
	{
		try 
		{
			Thread.sleep(time);
		} 
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}
		
}
	